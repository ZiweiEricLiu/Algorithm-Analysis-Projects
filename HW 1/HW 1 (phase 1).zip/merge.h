#ifndef MERGE_H
#define MERGE_H

#include <vector>

void merge(std::vector<int>& nums, std::vector<int>& L, std::vector<int>& R);

#endif

