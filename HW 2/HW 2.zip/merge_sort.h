#ifndef MERGE_SORT_H
#define MERGE_SORT_H

#include <vector>

void merge(std::vector<double>& nums, std::vector<double>& L, std::vector<double>& R);
void merge_sort(std::vector<double>& nums);

#endif