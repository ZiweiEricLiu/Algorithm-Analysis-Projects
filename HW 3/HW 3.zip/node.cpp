#include "node.h"

// implement member functions for the Node class here
Node::Node(int new_id)
	:id{ new_id }
{}